package com.impacta.as_003_cb_rb_tb

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.telainicial.*

class MainActivity : AppCompatActivity() {

    private lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.telainicial)

        iniVars()
        iniActions()
    }

    private fun iniVars() {
        context = this

        dbToScreen()
        screenToDb()
    }

    private fun dbToScreen() {
        // o que vem do banco de dados 1 = checked 0 = unchedcked
        val sabe_ios = 1
        val sabe_android = 0

        val sexo = "m"

        val tomada = true

        cb_ios.isChecked = sabe_ios == 1
        cb_android.isChecked = sabe_android == 1

        when(sexo.toLowerCase()) {
            "m" -> rb_m.isChecked = true
            "f" -> rb_f.isChecked = true
            else -> {
                // ??? Log erro
            }
        }

        tb_tomada.isChecked = tomada
    }

    private fun screenToDb() {
        // captura da tela para o BD
        var sabe_ios = -1
        var sabe_android = -1

        var sexo = ""

        var tomada = false

        if (cb_ios.isChecked) {
            sabe_ios = 1
        } else {
            sabe_ios = 0
        }
        if (cb_android.isChecked) {
            sabe_android = 1
        } else {
            sabe_android = 0
        }

        when(rg.checkedRadioButtonId) {
            R.id.rb_m -> sexo = "m"
            R.id.rb_f -> sexo = "f"
            else -> {
                /// ???
                rg.clearCheck()
            }
        }

        tomada = tb_tomada.isChecked
    }

    private fun iniActions() {
        cb_ios.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                Toast.makeText(context, "Sei iOs", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Naooooo Sei iOs", Toast.LENGTH_SHORT).show()
            }
        }

        rg.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId) {
                R.id.rb_m -> Toast.makeText(context, "Masculino", Toast.LENGTH_SHORT).show()
                R.id.rb_f -> Toast.makeText(context, "Feminino", Toast.LENGTH_SHORT).show()
                else -> {

                }
            }
        }
    }

}

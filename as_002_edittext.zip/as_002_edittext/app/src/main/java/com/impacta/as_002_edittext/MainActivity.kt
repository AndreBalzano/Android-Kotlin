package com.impacta.as_002_edittext

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.telainicial.*

class MainActivity : AppCompatActivity() {

    private lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.telainicial)

        context = this

        btn_ativar.setOnClickListener {


            val idade = et_idade.text.toString()

            Toast.makeText(
                context,
                idade,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}

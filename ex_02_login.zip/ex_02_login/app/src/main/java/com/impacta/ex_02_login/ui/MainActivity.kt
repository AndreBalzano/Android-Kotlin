package com.impacta.ex_02_login.ui

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.impacta.ex_02_login.R
import com.impacta.ex_02_login.util.DB
import com.impacta.ex_02_login.util.showMessage
import kotlinx.android.synthetic.main.login.*

class MainActivity : AppCompatActivity() {

    private lateinit var context: Context
    private var mensagemId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        iniVars()
        iniActions()
    }

    private fun iniVars() {
        context = this
    }

    private fun iniActions() {
        btn_cancelar.setOnClickListener {
            limparForm()
        }

        btn_login.setOnClickListener {
            if (validarForm()) {
                validarLogin()
            } else {
                exibirErro(mensagemId)
            }
        }
    }

    private fun limparForm() {
        et_nome.setText("")
        et_senha.setText("")

        et_nome.requestFocus() // extra
    }

    private fun validarForm(): Boolean {
        val nome = et_nome.text.toString().DB()
        val senha = et_senha.text.toString().DB()

        if (nome.isEmpty()) {
            mensagemId = R.string.msg_erro_no_name

            return false
        }

        if (senha.isEmpty()) {
            mensagemId = R.string.msg_erro_no_password

            return false
        }

        return true
    }

    private fun validarLogin() {
        val nome = et_nome.text.toString().DB()
        val senha = et_senha.text.toString().DB()

        if (!nome.equals("Hugo", true) || senha != "T123") {
            mensagemId = R.string.msg_erro_invalid_credentials
        } else {
            mensagemId = R.string.msg_sucess_menu
        }

        showMessage(context, mensagemId)
    }

    private fun exibirErro(mensagemId: Int) {
        showMessage(context, mensagemId)
    }
}

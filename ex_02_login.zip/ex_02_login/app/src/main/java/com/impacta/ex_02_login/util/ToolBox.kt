package com.impacta.ex_02_login.util

import android.content.Context
import android.widget.Toast

fun String.DB() : String {
    return this.trim()
}

fun showMessage(context: Context, resID: Int) {
    Toast.makeText(
        context,
        resID,
        Toast.LENGTH_SHORT
    ).show()
}

fun showMessage(context: Context, messagem: String) {
    Toast.makeText(
        context,
        messagem,
        Toast.LENGTH_SHORT
    ).show()
}
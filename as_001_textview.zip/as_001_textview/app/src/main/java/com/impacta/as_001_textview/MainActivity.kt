package com.impacta.as_001_textview


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.telainicial.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.telainicial)

        tv_android.text = "Android New"
        tv_impacta.text = "Impacta New"
        tv_impacta.setTextColor(resources.getColor(R.color.vermelho_paulista))


    }
}
